public class Jail extends Field {

    public Jail(int ID, String label, int cost) {
        super(ID, label, cost, 0);

    }
}
