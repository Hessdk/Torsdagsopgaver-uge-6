public class Main {
    private static Game game = new Game();
    public static void main(String[] args) {

        game.gameSetup();
        game.saveGame();

        //   game.displayPlayers();

        //lav lidt om på en player
        //


    }



}
