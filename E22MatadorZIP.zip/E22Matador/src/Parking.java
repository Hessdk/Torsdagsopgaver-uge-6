public class Parking extends Field {
    public Parking(int ID, String label) {
        super(ID, label, 0, 0);
    }
}
