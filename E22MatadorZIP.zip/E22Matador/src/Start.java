public class Start extends Field {

    public Start(int ID, String label, int cost, int income) {
        super(ID, label, cost, income);
    }

}
